import styles from './image.module.css'
export const image = (url) =>{
    const img = document.createElement('div')
    img.classList.add(styles.image)
    img.style.backgroundImage = `url(${url})`;
    return img;
}