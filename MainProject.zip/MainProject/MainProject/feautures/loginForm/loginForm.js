import {getInput} from "../../components/input";
import {button} from "../../components/button";
import styles from "./loginForm.module.css"
export const getUserForm = () => {
    const form = document.createElement('form');

    form.setAttribute('id','userId')
    form.classList.add(styles.form)
    form.append(
        getInput({ type: 'text', inputTitle: 'Email',id:'login',style: styles.input }),
        getInput({ type: 'password', inputTitle: 'Пароль',id: 'email', style: styles.input }),
        button("Войти",styles.btn),
        button('Зарегистрироваться',styles.btn)
    );

    return form;
};