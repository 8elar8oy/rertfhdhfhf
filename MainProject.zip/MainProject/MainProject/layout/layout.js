import {homePage} from "../../pages/home";
import {aboutPage} from "../../pages/about";

export const getLayout = () => {
    const div = document.createElement('div')

    if (window.location.pathname === '/') {
        div.append(homePage());
    }

    if (window.location.pathname === '/about') {
        div.append(aboutPage());
    }

    return div
}