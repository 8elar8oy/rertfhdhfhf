
import {profile} from "../pages/profile";
import {registrationPage} from "/pages/registrationPage";

export const getLayout = () => {
    const div = document.createElement('div')

    if (window.location.pathname === '/') {
        div.append(registrationPage());
    }

    if (window.location.pathname === '/about') {
        div.append(profile())
    }

    return div
}