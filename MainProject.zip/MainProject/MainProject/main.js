import './style.css'
import {registrationPage} from "./pages/registrationPage";


const app = document.querySelector('#app')
app.append(registrationPage())





