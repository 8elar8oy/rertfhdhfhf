import styles from './profile.module.css'
export const profile = () =>{
    const profileDiv = document.createElement('div')
    const appMenu = document.createElement('aside')
    const friendsList = document.createElement('aside')
    const publicationsList = document.createElement('ul')
    const header = document.createElement('header')
    const main = document.createElement('main')
    const footer = document.createElement('footer')

    profileDiv.append(header);
    profileDiv.append(appMenu);
    profileDiv.append(footer);
    main.append(friendsList);
    main.append(publicationsList);
    profileDiv.append(main);


    return profileDiv
}